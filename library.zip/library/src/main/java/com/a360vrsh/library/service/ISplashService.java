package com.a360vrsh.library.service;

import com.alibaba.android.arouter.facade.template.IProvider;


public interface ISplashService extends IProvider {
    void toSplash();
}
