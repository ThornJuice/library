package com.a360vrsh.library.util;

import android.view.View;

import com.mylhyl.circledialog.CircleDialog;
import com.mylhyl.circledialog.callback.ConfigButton;
import com.mylhyl.circledialog.params.ButtonParams;

/**
 * @author: wxj
 * @date: 2020/9/12
 * @description:
 */
public class CircleDialogUtil {
    public static void showAlert(){

    }
}
