package com.a360vrsh.library.listener;

public interface CommonAdapterClickListener {
    void onAdapterClick(int position, int resId,Object value);
}