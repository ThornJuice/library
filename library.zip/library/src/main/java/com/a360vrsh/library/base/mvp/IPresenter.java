package com.a360vrsh.library.base.mvp;

public interface IPresenter {
    void init();
}
