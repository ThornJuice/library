package com.a360vrsh.library.base.mvp;

import androidx.lifecycle.LifecycleObserver;

public interface IModel extends LifecycleObserver {
}
